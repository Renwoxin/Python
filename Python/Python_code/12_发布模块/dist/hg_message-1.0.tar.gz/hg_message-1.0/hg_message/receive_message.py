def receive():
    return "这是来自XXX的短信"