def send(text):

    print("正在发送...")