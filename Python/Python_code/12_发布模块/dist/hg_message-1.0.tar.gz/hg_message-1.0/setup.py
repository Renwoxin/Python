from distutils.core import setup

setup(name="hg_message",
      version="1.0",
      description="hg发送和接收消息模块",
      long_description="完整的发送和接收消息模块",
      author="hg",
      author_email="666666@qq.com",
      url="www.hg.com",
      py_modules = ["hg_message.send_message",
                    "hg_message.receive_message"])